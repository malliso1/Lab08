package com.testcoursesprovider;

import android.content.ContentProviderClient;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ContentValues values1 = new ContentValues();
        values1.put("title", "BASH Scripting");
        values1.put("code", "OPS435");
        values1.put("room", "T3175");

        ContentValues values2 = new ContentValues();
        values2.put("title", "Unix System");
        values2.put("code", "PRO511");
        values2.put("room", "S2153");
        Uri uri = getContentResolver().insert(
                Uri.parse(
                        "content://seneca.ict.provider/courses"),
                values1);

        uri = getContentResolver().insert(
                Uri.parse(
                        "content://seneca.ict.provider/courses"),
                values2);


        List<String> courses = new ArrayList<>();

        Uri allCourses = Uri.parse(
                "content://seneca.ict.provider/courses");

        ContentProviderClient coursesProvider = getContentResolver().acquireContentProviderClient(allCourses);

        Cursor c;
        if (android.os.Build.VERSION.SDK_INT <11) {
            //---before Honeycomb---
            c = managedQuery(allCourses, null, null, null,
                    "title desc");
        } else {
            //---Honeycomb and later---
            CursorLoader cursorLoader = new CursorLoader(
                    this,
                    allCourses, null, null, null,
                    "title desc");
            c = cursorLoader.loadInBackground();
        }

        if (c.moveToFirst()) {
            int count = 0;
            do{
                StringBuilder tempString = new StringBuilder("");
                tempString.append(c.getString(c.getColumnIndex("_id")) + ", " +
                                c.getString(c.getColumnIndex(
                                        "title")) + ", " +
                                c.getString(c.getColumnIndex(
                                        "code")) + ", " +
                                c.getString(c.getColumnIndex("room")));
                courses.add(tempString.toString());
                count++;
            } while (c.moveToNext());
        }

        ListView lv = (ListView) findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, courses);
        lv.setAdapter(adapter);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
